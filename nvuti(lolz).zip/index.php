<?php
/*

Автор данного скрипта - https://vk.com/debl0w, по всем вопросам пишите.

*/
  require("inc/site_config.php"); 
require("inc/main.php"); 


?>