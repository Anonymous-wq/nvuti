<?php
/*

Автор данного скрипта - https://vk.com/debl0w, по всем вопросам пишите.

*/
require("bd.php");
require("function.php");
?>